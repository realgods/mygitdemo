package me.ele.zs.client.warehouse.dto;

import java.util.Date;

import me.ele.zs.client.common.dto.BaseInput;

/**
 * 仓库领用单对象
 * 
 * @Create_by Ranger
 * @Create_Date 2016年4月18日下午4:48:06
 */
public class WarehouseUsedIpt extends BaseInput {

    private static final long serialVersionUID = 6892099619871078161L;

    /*
     * 领用单id
     */
    private Long id;
    
    /*
     * 领用备注
     */
    private String remark;
    /*
     * 退货仓库所属城市id
     */
    private Long warehouseCityId;
    /*
     * 退货仓库所属城市名称
     */
    private String warehouseCityName;
    
    /*
     * 仓库id
     */
    private Long warehouseId;
    /*
     * 仓库编号
     */
    private String warehouseNo;
    /*
     * 仓库名
     */
    private String warehouseName;
    /*
     * 状态：0 已取消 10 初始化 20 已出库
     */
    private Integer status;
    private Integer updateStatus;
    /*
     * 领用人id
     */
    private Long userId;
    /*
     * 领用人
     */
    private String userName;
    /*
     * 出库人id
     */
    private Long deliveryUserId;
    /*
     * 出库人
     */
    private String deliveryUserName;
    /*
     * 出库时间
     */
    private Date deliveryTime;
    
    
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getWarehouseCityId() {
        return warehouseCityId;
    }
    public void setWarehouseCityId(Long warehouseCityId) {
        this.warehouseCityId = warehouseCityId;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getWarehouseCityName() {
        return warehouseCityName;
    }
    public void setWarehouseCityName(String warehouseCityName) {
        this.warehouseCityName = warehouseCityName;
    }
    public Long getWarehouseId() {
        return warehouseId;
    }
    public void setWarehouseId(Long warehouseId) {
        this.warehouseId = warehouseId;
    }
    public String getWarehouseNo() {
        return warehouseNo;
    }
    public void setWarehouseNo(String warehouseNo) {
        this.warehouseNo = warehouseNo;
    }
    public String getWarehouseName() {
        return warehouseName;
    }
    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getUpdateStatus() {
        return updateStatus;
    }
    public void setUpdateStatus(Integer updateStatus) {
        this.updateStatus = updateStatus;
    }
    public Long getDeliveryUserId() {
        return deliveryUserId;
    }
    public void setDeliveryUserId(Long deliveryUserId) {
        this.deliveryUserId = deliveryUserId;
    }
    public String getDeliveryUserName() {
        return deliveryUserName;
    }
    public void setDeliveryUserName(String deliveryUserName) {
        this.deliveryUserName = deliveryUserName;
    }
    public Date getDeliveryTime() {
        return deliveryTime;
    }
    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
}

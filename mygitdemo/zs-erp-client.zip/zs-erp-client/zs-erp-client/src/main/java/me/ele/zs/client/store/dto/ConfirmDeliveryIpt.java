package me.ele.zs.client.store.dto;


import me.ele.zs.client.common.dto.BaseInput;

/**
 * 门店采购／强配 出库单
 * @author 朱峰
 *
 */
public class ConfirmDeliveryIpt  extends BaseInput{
	/**
	 * 
	 */
	private static final long serialVersionUID = -648087378314744755L;
	/**
	 * 采购单id（来自erp）
	 */
	private Long purchaseId;
	/**
	 * 出库单id（来自wms）
	 */
	private Long deliveryId;
	
	public Long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(Long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public Long getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Long deliveryId) {
		this.deliveryId = deliveryId;
	}
	
}

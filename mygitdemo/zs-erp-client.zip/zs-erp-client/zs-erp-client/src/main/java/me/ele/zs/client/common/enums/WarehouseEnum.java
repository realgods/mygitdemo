package me.ele.zs.client.common.enums;


/**
 * 仓库相关枚举类
 * 
 * @Create_by Ranger
 * @Create_Date 2016年4月19日下午8:40:42
 */
public class WarehouseEnum {
    
	public enum ReturnSupplierStatus {
		CACEL(0,"已取消"),
		INIT(10,"初始化"),
		DELIVERIED(20,"已出库");
		
		private Integer value;
		private String name;
		
		private ReturnSupplierStatus(Integer value,String name) {
			this.value = value;
			this.name = name;
		}
		public Integer getValue() {
			return this.value;
		}
		public String getName() {
            return name;
        }
        
        public static String getNameByValue(int value) {
            for (ReturnSupplierStatus item : ReturnSupplierStatus.values()) {
                if (item.value == value) {
                    return item.name;
                }
            }
            return null;
        }
	}
	
	public enum ReturnSupplierReasonStatus {
        ERROR(1,"发错货"),
        EXPIRE(2,"临期或过期"),
        RESALE(3,"返销"),
        OTHER(0,"其他");
        
        private Integer value;
        private String name;
        
        private ReturnSupplierReasonStatus(Integer value,String name) {
            this.value = value;
            this.name = name;
        }
        public Integer getValue() {
            return this.value;
        }
        public String getName() {
            return name;
        }
        
        public static String getNameByValue(int value) {
            for (ReturnSupplierReasonStatus item : ReturnSupplierReasonStatus.values()) {
                if (item.value == value) {
                    return item.name;
                }
            }
            return null;
        }
    }
	public enum UsedStatus {
        CACEL(0,"已取消"),
        INIT(10,"初始化"),
        DELIVERIED(20,"已出库");
        
        private Integer value;
        private String name;
        
        private UsedStatus(Integer value,String name) {
            this.value = value;
            this.name = name;
        }
        public Integer getValue() {
            return this.value;
        }
        public String getName() {
            return name;
        }
        
        public static String getNameByValue(int value) {
            for (UsedStatus item : UsedStatus.values()) {
                if (item.value == value) {
                    return item.name;
                }
            }
            return null;
        }
    }
	public enum ScrappedStatus {
        CACEL(0,"已取消"),
        INIT(10,"初始化"),
        DELIVERIED(20,"已出库");
        
        private Integer value;
        private String name;
        
        private ScrappedStatus(Integer value,String name) {
            this.value = value;
            this.name = name;
        }
        public Integer getValue() {
            return this.value;
        }
        public String getName() {
            return name;
        }
        
        public static String getNameByValue(int value) {
            for (ScrappedStatus item : ScrappedStatus.values()) {
                if (item.value == value) {
                    return item.name;
                }
            }
            return null;
        }
    }
}

package me.ele.zs.client.store.service;

import me.ele.zs.client.common.dto.ResponseDto;
import me.ele.zs.client.store.dto.ReturnTakeDeliveryIpt;

public interface ErpStoreReturnService {
	/**
	 * 接受退货仓库收货确认通知
	 * @return
	 */
	ResponseDto<Boolean> takeDeliveryNotification(ReturnTakeDeliveryIpt takeDeliveryNotificationIpt);
}

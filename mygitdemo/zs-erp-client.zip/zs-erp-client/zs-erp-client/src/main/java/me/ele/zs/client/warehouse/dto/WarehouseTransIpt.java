package me.ele.zs.client.warehouse.dto;

import java.util.List;

import me.ele.zs.client.common.dto.BaseInput;

public class WarehouseTransIpt extends BaseInput {

    private static final long serialVersionUID = 6892099619871078161L;

    /**
     * 调拨单id
     */
    private Long warehouseTransId;
    
    /**
     * 状态:20：已发货；30：已收货
     */
    private Integer status;
    
    private Long actorId;
    
    private String actorName;
    
    private List<WarehouseTransItemIpt> itemList;

    public Long getWarehouseTransId() {
        return warehouseTransId;
    }

    public void setWarehouseTransId(Long warehouseTransId) {
        this.warehouseTransId = warehouseTransId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getActorId() {
        return actorId;
    }

    public void setActorId(Long actorId) {
        this.actorId = actorId;
    }

    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    public List<WarehouseTransItemIpt> getItemList() {
        return itemList;
    }

    public void setItemList(List<WarehouseTransItemIpt> itemList) {
        this.itemList = itemList;
    }
}

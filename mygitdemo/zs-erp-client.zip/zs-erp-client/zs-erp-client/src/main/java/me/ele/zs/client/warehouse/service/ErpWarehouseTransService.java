package me.ele.zs.client.warehouse.service;

import me.ele.zs.client.common.dto.ResponseDto;
import me.ele.zs.client.warehouse.dto.WarehouseTransIpt;

/**
 * 供应量-仓库调拨业务相关接口
 * 
 * @author like
 *
 */
public interface ErpWarehouseTransService {

    /**
     * wms仓库调拨出库、入库更新erp调拨单状态接口
     * 
     * @param ipt
     * @return
     */
    ResponseDto<Boolean> updateTransStatus(WarehouseTransIpt ipt);

}

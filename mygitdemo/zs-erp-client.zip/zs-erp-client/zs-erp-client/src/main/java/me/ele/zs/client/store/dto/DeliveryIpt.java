package me.ele.zs.client.store.dto;

import java.util.List;

import me.ele.zs.client.common.dto.BaseInput;
import me.ele.zs.client.common.enums.StoreEnum;

/**
 * 门店采购／强配 出库单
 * @author 朱峰
 *
 */
public class DeliveryIpt  extends BaseInput{
	/**
	 * 
	 */
	private static final long serialVersionUID = -648087378314744755L;
	/**
	 * 采购单id（来自erp）
	 */
	private Long purchaseId;
	/**
	 * 出库单id（来自wms）
	 */
	private Long deliveryId;
	/**
	 * 出库单状态
	 * 10 待配送
	 * 15 待审核
	 * 20 待收货  
	 * 40 已收货
	 */
	private StoreEnum.DeliveryStatus status;
	/**
	 * 出库物料详情
	 */
	private List<DeliveryItemIpt> deliveryItemList;
	
	private String deliveryTime;
	
	public Long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(Long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public Long getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Long deliveryId) {
		this.deliveryId = deliveryId;
	}
	public StoreEnum.DeliveryStatus getStatus() {
		return status;
	}
	public void setStatus(StoreEnum.DeliveryStatus status) {
		this.status = status;
	}
	public List<DeliveryItemIpt> getDeliveryItemList() {
		return deliveryItemList;
	}
	public void setDeliveryItemList(List<DeliveryItemIpt> deliveryItemList) {
		this.deliveryItemList = deliveryItemList;
	}
	public String getDeliveryTime() {
		return deliveryTime;
	}
	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	
}

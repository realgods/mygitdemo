package me.ele.zs.client.common.enums;

import me.ele.zs.component.core.IReturnCode;

public class StoreEnum {
	public enum DeliveryStatus {
		INITIAL(0),
		//未出库
		UN_DELIVERY(10),
		//待审核
		UN_AUDIT(15),
		
		AUDIT(16),
		//待收货
		UN_TAKE_DELIVERY(20),
		//已收货
		TAKE_DELIVERY(40),
		;
		private Integer type;
		private DeliveryStatus(Integer type) {
			this.type = type;
		}
		public Integer getType() {
			return this.type;
		}
	}
	
	public enum ReturnCode implements IReturnCode {
		SUCCESS("000000", "操作成功"),
		DELIVERY_ERROR("100001", "门店订货出库调用异常"),
		
		RETURN_PARAM_ERROR("200001" , "参数错误"),
		RETURN_INFO_NOT_EXISTS("200002" , "门店出货单不存在"),
		
		
		RETURN_DUPLICATE("200003" , "重复确认收货"),
		
		RETURN_ERROR("200004", "退货确认收货错误"),
		;
		private String code;
		private String msg;
		
		private ReturnCode(String code, String msg) {
			this.code = code;
			this.msg = msg;
		}
		@Override
		public String getCode() {
			// TODO Auto-generated method stub
			return this.code;
		}

		@Override
		public String getMsg() {
			// TODO Auto-generated method stub
			return this.msg;
		}
		
	}
}

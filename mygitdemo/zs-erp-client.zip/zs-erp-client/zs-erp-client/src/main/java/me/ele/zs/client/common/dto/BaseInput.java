package me.ele.zs.client.common.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 客户端入参基类
 */
public class BaseInput implements Serializable {

    private static final long serialVersionUID = -8077289177180818016L;

    /**
     * 客户端ip
     */
    private String clientIp;
    /**
     * 操作人Id
     */
    private Long operatorId;
    /**
     * 操作人
     */
    private String operator;
    /**
     * 操作时间
     */
    private Date operateTime;

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Date getOperateTime() {
        return operateTime;
    }

    public void setOperateTime(Date operateTime) {
        this.operateTime = operateTime;
    }

}

package me.ele.zs.client.common.dto;

import me.ele.zs.component.core.IReturnCode;

public class ResponseDto<T> {

    private String code;
    private T data;
    private String message;

    public ResponseDto() {
    }

    public ResponseDto(IReturnCode IReturnCode, T data) {
        this.code = IReturnCode.getCode();
        this.message = IReturnCode.getMsg();
        this.data = data;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

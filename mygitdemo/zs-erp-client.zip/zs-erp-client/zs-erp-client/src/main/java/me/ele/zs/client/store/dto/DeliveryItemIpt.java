package me.ele.zs.client.store.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 门店订货／强配 出库单明细
 * @author 朱峰
 *
 */
public class DeliveryItemIpt implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5886100473652644447L;
	/**
	 * 物料id
	 */
	private Long materialId;
	
	/**
	 * 物料数量
	 */
	private Integer quantity;
	/**
	 * 批次详情
	 */
	private List<DeliveryItemBashIpt> deliveryItemBashList;
	public Long getMaterialId() {
		return materialId;
	}
	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public List<DeliveryItemBashIpt> getDeliveryItemBashList() {
		return deliveryItemBashList;
	}
	public void setDeliveryItemBashList(
			List<DeliveryItemBashIpt> deliveryItemBashList) {
		this.deliveryItemBashList = deliveryItemBashList;
	}
	
}

package me.ele.zs.client.warehouse.service;

import me.ele.zs.client.common.dto.ResponseDto;
import me.ele.zs.client.warehouse.dto.WarehouseReturnSupplierIpt;

/**
 * 仓库退供应商接口类
 * 
 * @Create_by Ranger
 * @Create_Date 2016年4月18日下午4:54:33
 */
public interface ErpWarehouseReturnSupplierService {
    
    /**
     * 出库更新单据状态
     * 
     * @param warehouseReturnSupplierIpt:
     *         warehouseReturnSupplierIpt.id、deliveryTime、warehouseId,
     *         deliveryUserId、deliveryUserName、operatorId、operator不能为空
     *         clientIp选填
     *         
     * @return ResponseDto<Boolean>:
     *          ResponseDto.code.equal(ReturnCode.SUCCESS.getCode())则表示成功 
     * @Create_by Ranger
     * @Create_date 2016年4月18日下午5:03:28
     */
    ResponseDto<Boolean> updateDeliveryStatus(WarehouseReturnSupplierIpt warehouseReturnSupplierIpt);
}

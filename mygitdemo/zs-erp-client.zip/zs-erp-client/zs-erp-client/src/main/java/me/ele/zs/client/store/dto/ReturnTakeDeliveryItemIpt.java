package me.ele.zs.client.store.dto;

import java.io.Serializable;

/**
 * 退货确认收货通知入参明细
 * @author 朱峰
 *
 */
public class ReturnTakeDeliveryItemIpt implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3077557532339332732L;

	/**
	 * 物料id
	 */
	private Long materialId;
	
	/**
	 * 物料数量
	 */
	private Integer quantity;
	
	/**
	 * 生产日期
	 */
	private String productionDate;
	public Long getMaterialId() {
		return materialId;
	}
	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getProductionDate() {
		return productionDate;
	}
	public void setProductionDate(String productionDate) {
		this.productionDate = productionDate;
	}
	
}

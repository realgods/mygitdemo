package me.ele.zs.client.store.dto;

import java.io.Serializable;

/**
 * 门店订货／强配 出库单批次明细
 * @author 朱峰
 *
 */
public class DeliveryItemBashIpt implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1230158043418542578L;
	/**
	 * 生产日期
	 */
	private String productionDate;
	/**
	 * 数量
	 */
	private Integer quantity;
	public String getProductionDate() {
		return productionDate;
	}
	public void setProductionDate(String productionDate) {
		this.productionDate = productionDate;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}

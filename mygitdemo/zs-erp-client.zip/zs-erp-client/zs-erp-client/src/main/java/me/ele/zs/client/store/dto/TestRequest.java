package me.ele.zs.client.store.dto;

import me.ele.zs.client.common.dto.BaseInput;

public class TestRequest extends BaseInput {

    private static final long serialVersionUID = 1137800081312681480L;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

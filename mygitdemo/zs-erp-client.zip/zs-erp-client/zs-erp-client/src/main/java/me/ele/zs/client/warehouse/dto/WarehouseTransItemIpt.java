package me.ele.zs.client.warehouse.dto;

import java.util.Date;

public class WarehouseTransItemIpt {

    /**
     * 物料id
     */
    private Long materialId;
    
    /**
     * 生产日期
     */
    private Date productionDate;
    /**
     * 实收数量
     */
    private Integer receiveQuantity;
    
    public Long getMaterialId() {
        return materialId;
    }
    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }
    public Date getProductionDate() {
        return productionDate;
    }
    public void setProductionDate(Date productionDate) {
        this.productionDate = productionDate;
    }
    public Integer getReceiveQuantity() {
        return receiveQuantity;
    }
    public void setReceiveQuantity(Integer receiveQuantity) {
        this.receiveQuantity = receiveQuantity;
    }
}

package me.ele.zs.client.common.enums;

/**
 * 仓库调拨装态
 * 
 * @author like
 */
public enum WarehouseTransStatusEnum {

    /**
     */
    INIT(10, "初始化"),
    
    TRANS_OUT(20, "已出库"),

    /**
     */
    TRANS_IN(30, "已入库"),

    /**
     */
    CANCEL(40, "已取消");

    private Integer STATUS;
    
    private String desc;

    private WarehouseTransStatusEnum(Integer STATUS, String desc) {
        this.STATUS = STATUS;
        this.desc = desc;
    }

    public Integer getStatus() {
        return STATUS;
    }
    
    public static String getDesc(Integer status) {
        for(WarehouseTransStatusEnum e : WarehouseTransStatusEnum.values()) {
            if(status == e.getStatus()) {
                return e.desc;
            }
        }
        return null;
    }

}

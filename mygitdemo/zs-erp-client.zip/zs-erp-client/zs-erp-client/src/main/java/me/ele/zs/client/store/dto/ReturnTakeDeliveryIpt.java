package me.ele.zs.client.store.dto;

import java.util.List;

import me.ele.zs.client.common.dto.BaseInput;

/**
 * 退货确认收货通知入参
 * @author 朱峰
 *
 */
public class ReturnTakeDeliveryIpt  extends BaseInput{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6684928716705397598L;

	/**
	 * 出库单（erp）
	 */
	private Long storeReturnOutId;
	
	/**
	 * 入库单（wms）
	 */
	private String storeReturnInId;
	
	/**
	 * 退货物料详情
	 */
	private List<ReturnTakeDeliveryItemIpt> storeReturnItemList;

	public Long getStoreReturnOutId() {
		return storeReturnOutId;
	}

	public void setStoreReturnOutId(Long storeReturnOutId) {
		this.storeReturnOutId = storeReturnOutId;
	}

	public String getStoreReturnInId() {
		return storeReturnInId;
	}

	public void setStoreReturnInId(String storeReturnInId) {
		this.storeReturnInId = storeReturnInId;
	}

	public List<ReturnTakeDeliveryItemIpt> getStoreReturnItemList() {
		return storeReturnItemList;
	}

	public void setStoreReturnItemList(List<ReturnTakeDeliveryItemIpt> storeReturnItemList) {
		this.storeReturnItemList = storeReturnItemList;
	}
	
	
}

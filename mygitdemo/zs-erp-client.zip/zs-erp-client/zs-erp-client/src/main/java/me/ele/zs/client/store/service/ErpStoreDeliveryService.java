package me.ele.zs.client.store.service;

import me.ele.zs.client.common.dto.ResponseDto;
import me.ele.zs.client.store.dto.ConfirmDeliveryIpt;
import me.ele.zs.client.store.dto.DeliveryIpt;

/**
 * 门店配送service
 */
public interface ErpStoreDeliveryService {
	
	/**
	 * 仓库发货通知
	 * @return
	 */
	ResponseDto<Boolean> deliveryNotification(DeliveryIpt ipt);

	ResponseDto<Boolean> confirmDeliveryNotification(ConfirmDeliveryIpt ipt);
	
}
